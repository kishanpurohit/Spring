package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

/**
 * 
 * @author Dushyant
 * This is Bean Class For Technical Query
 * JPA uses it
 */
@Entity
@Table(name = "query_master")
public class TechnicalQuery {

	@Id
	@Column(name="query_Id")
	int queryId;

	@Column(name="technology")
	String technology;

	@Column(name="query_raised_by")
	String queryRaisedBy;

	@Column(name="query")
	String query;

	@Column(name="solutions")
	@NotEmpty(message = "Solution field should not kept blank")
	String solution;

	@Column(name="solution_given_by")
	@NotEmpty(message = "You Must Select one of the name")
	String solutionGivenBy;

	public TechnicalQuery() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TechnicalQuery(int queryId, String technology, String queryRaisedBy,
			String query, String solution, String solutionGivenBy) {
		this.queryId = queryId;
		this.technology = technology;
		this.queryRaisedBy = queryRaisedBy;
		this.query = query;
		this.solution = solution;
		this.solutionGivenBy = solutionGivenBy;
	}

	public int getQueryId() {
		return queryId;
	}

	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}

	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}

	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}

	@Override
	public String toString() {
		return "TechnicalQuery [queryId=" + queryId + ", technology="
				+ technology + ", queryRaisedBy=" + queryRaisedBy + ", query="
				+ query + ", solution=" + solution + ", solutionGivenBy="
				+ solutionGivenBy + "]";
	}
}
