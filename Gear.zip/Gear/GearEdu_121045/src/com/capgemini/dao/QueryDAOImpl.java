package com.capgemini.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.bean.TechnicalQuery;
import com.capgemini.exception.technicalQueryException;

/**
 * 
 * @author Dushyant
 * DAO Layer Class
 *
 */
@Repository
public class QueryDAOImpl implements IQueryDAO {

	@PersistenceContext
	EntityManager entityManager;
	
	/**
	 * Function to retrieving query
	 */
	@Override
	public TechnicalQuery getTechnicalQuery(int queryId)
			throws technicalQueryException {
		TechnicalQuery technicalQuery;
		try {
			technicalQuery = entityManager.find(TechnicalQuery.class, queryId);
			if (technicalQuery == null)
				throw new technicalQueryException(
						"Query not found, wrong query id : " + queryId);
			/*
			 * In this case the query with specific id cannot be found so a
			 * exception is thrown by checking null and caught here as another
			 * exception while using JPA can also occur so both the exception
			 * will be caught by the same block ` and thrown to the controller
			 */
		} catch (Exception e) {
			throw new technicalQueryException(e.getMessage());
		}
		return technicalQuery;
	}

	/**
	 * Fuction to update query with solution
	 */
	@Override
	public boolean updateTechnicalQuery(TechnicalQuery technicalQuery)
			throws technicalQueryException {

		try {
			entityManager.merge(technicalQuery);
		} catch (Exception e) {
			throw new technicalQueryException("Error Answering Query");
		}
		return true;
	}

}
