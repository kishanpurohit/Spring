package com.capgemini.dao;

import com.capgemini.bean.TechnicalQuery;
import com.capgemini.exception.technicalQueryException;

public interface IQueryDAO {

	TechnicalQuery getTechnicalQuery(int queryId) throws technicalQueryException;

	boolean updateTechnicalQuery(TechnicalQuery technicalQuery) throws technicalQueryException;

}
