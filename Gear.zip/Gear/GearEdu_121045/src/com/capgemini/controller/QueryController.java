package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.bean.TechnicalQuery;
import com.capgemini.exception.technicalQueryException;
import com.capgemini.service.IQueryService;

/**
 * 
 * @author Dushyant
 * Controller Class
 *
 */
@Controller
public class QueryController {

	@Autowired
	IQueryService service;

	/**
	 * 
	 * redirects to the home page
	 */
	@RequestMapping("/home")
	public String home() {
		return "home";
	}

	/**
	 * 
	 * redirects to the answer Query Page
	 */
	@RequestMapping("/answerQueryForm")
	public String answerQueryForm(@RequestParam("queryId") int queryId,
			Model model) {
		List<String> sme = new ArrayList<String>();
		try {
			TechnicalQuery technicalQuery = service.getTechnicalQuery(queryId);
			System.out.println(technicalQuery);
			sme.add("");
			sme.add("Uma");
			sme.add("Rahul");
			sme.add("Kavita");
			sme.add("Hema");
			model.addAttribute("query", technicalQuery);
			model.addAttribute("sme", sme);
		} catch (technicalQueryException e) {
			model.addAttribute("errorMessage", e.getMessage());
			return "error";
		}
		return "answerQueryForm";
	}

	/**
	 * 
	 * Checks for validation
	 * On Success Redirects to success page
	 */
	@RequestMapping("/answerQuery")
	public String answerQuery(
			@ModelAttribute("query") @Valid TechnicalQuery technicalQuery,
			BindingResult result, Model model) {
		System.out.println(result.hasErrors());
		if (result.hasErrors()) {
			System.out.println("hasErrors");
			List<String> sme = new ArrayList<String>();
			sme.add("Uma");
			sme.add("Rahul");
			sme.add("Kavita");
			sme.add("Hema");
			model.addAttribute("query", technicalQuery);
			model.addAttribute("sme", sme);
			return "answerQueryForm";
		} else {
			boolean isUpdated;
			try {
				isUpdated = service.updateTechnicalQuery(technicalQuery);
				if (!isUpdated) {
					model.addAttribute("errorMessage",
							"Query Could Not Be Updated");
					return "error";
				}
				model.addAttribute("successMessage", "Solution for Query Id : "
						+ technicalQuery.getQueryId()
						+ "submitted successfully");
			} catch (technicalQueryException e) {
				model.addAttribute("errorMessage", e.getMessage());
				return "error";
			}
		}
		return "success";
	}
}
