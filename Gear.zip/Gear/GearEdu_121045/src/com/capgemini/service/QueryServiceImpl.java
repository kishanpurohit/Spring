package com.capgemini.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.TechnicalQuery;
import com.capgemini.dao.IQueryDAO;
import com.capgemini.exception.technicalQueryException;

/**
 * 
 * @author Dushyant
 * Service Layer Class
 *
 */
@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDAO dao;
	
	/**
	 * Function for retrieving Query
	 */
	@Override
	public TechnicalQuery getTechnicalQuery(int queryId) throws technicalQueryException {
		return dao.getTechnicalQuery(queryId);
	}

	/**
	 * Updating Query with solution
	 */
	@Override
	public boolean updateTechnicalQuery(TechnicalQuery technicalQuery) throws technicalQueryException {
		return dao.updateTechnicalQuery(technicalQuery);
	}

}
