package com.capgemini.service;

import com.capgemini.bean.TechnicalQuery;
import com.capgemini.exception.technicalQueryException;

public interface IQueryService {

	TechnicalQuery getTechnicalQuery(int queryId) throws technicalQueryException;

	boolean updateTechnicalQuery(TechnicalQuery technicalQuery) throws technicalQueryException;

}
