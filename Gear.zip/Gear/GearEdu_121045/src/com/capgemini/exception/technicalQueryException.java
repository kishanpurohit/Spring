package com.capgemini.exception;

public class technicalQueryException extends Exception {

	public technicalQueryException(String message) {
		super(message);
	}
}
